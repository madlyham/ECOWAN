#!/usr/bin/env python3
"""Local integration smoke test; starts the service on a temporary port/state file."""
import json
import os
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def request(url, data=None):
    headers = {"Content-Type": "application/json"} if data is not None else {}
    req = urllib.request.Request(url, data=data, headers=headers, method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=3) as res:
            return res.status, res.read()
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read()


def main():
    port = free_port()
    with tempfile.TemporaryDirectory(prefix="edge-monitor-test-") as td:
        env = dict(os.environ)
        env.update({
            "DASH_HOST": "127.0.0.1",
            "DASH_PORT": str(port),
            "DASH_MQTT_ENABLED": "0",
            "DASH_HISTORY_FILE": str(Path(td) / "history.json"),
            "DASH_HTML_FILE": str(ROOT / "index.html"),
        })
        with open(Path(td) / "service.log", "w", encoding="utf-8") as log:
            proc = subprocess.Popen(["python3", "-u", str(ROOT / "edge_dash.py")], env=env, stdout=log, stderr=subprocess.STDOUT)
        base = f"http://127.0.0.1:{port}"
        try:
            for _ in range(60):
                if proc.poll() is not None:
                    raise RuntimeError((Path(td) / "service.log").read_text())
                try:
                    code, _ = request(base + "/healthz")
                    if code == 200:
                        break
                except Exception:
                    time.sleep(0.1)
            else:
                raise RuntimeError("service did not start")

            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            up = {
                "deduplicationId": "smoke-enode1-001",
                "time": now,
                "deviceInfo": {
                    "deviceName": "ENode1", "devEui": "d251f42dc4918f96",
                    "applicationName": "Env_Monitor", "deviceProfileName": "ESP32-AS923-Node"
                },
                "devAddr": "0112b3bd", "dr": 5, "fCnt": 248, "fPort": 1, "adr": True,
                "data": "C0AMgAAA",
                "object": {"temperature": 28.8, "humidity": 32, "moisture": 0},
                "rxInfo": [{"gatewayId": "a84041fdfe257d3b", "rssi": -59, "snr": 14.2, "channel": 1}],
                "txInfo": {"frequency": 923400000, "modulation": {"lora": {"bandwidth": 125000, "spreadingFactor": 7, "codeRate": "CR_4_5"}}},
            }
            status, body = request(base + "/?event=up", json.dumps(up).encode())
            assert status == 200 and body == b"OK", (status, body)
            state = json.loads(request(base + "/api/state")[1])
            n1 = next(n for n in state["nodes"] if n["eui"] == "d251f42dc4918f96")
            assert (n1["temperature"], n1["humidity"], n1["moisture"]) == (28.8, 32.0, 0.0), n1
            assert (n1["fcnt"], n1["rssi"], n1["snr"], n1["sf"]) == (248, -59.0, 14.2, 7), n1
            series = json.loads(request(base + "/api/series?since=0")[1])
            assert len(series["series"]["d251f42dc4918f96"]) == 1
            raw = json.loads(request(base + "/api/raw?eui=d251f42dc4918f96")[1])
            assert "up" in raw["raw"]

            status, body = request(base + "/?event=up", json.dumps(up).encode())
            assert status == 200 and b"duplicate" in body.lower(), (status, body)
            state = json.loads(request(base + "/api/state")[1])
            assert state["counts"]["dup"] >= 1
            assert len(json.loads(request(base + "/api/series?since=0")[1])["series"]["d251f42dc4918f96"]) == 1

            n2 = dict(up)
            n2["deduplicationId"] = "smoke-node2-001"
            n2["deviceInfo"] = {"deviceName": "Node 2", "devEui": "b1e299ff3eed5d1d"}
            n2["fCnt"] = 4
            n2["object"] = {"temperature": 25.1, "humidity": 53.5, "moisture": 1300}
            status, _ = request(base + "/?event=up", json.dumps(n2).encode())
            assert status == 200
            state = json.loads(request(base + "/api/state")[1])
            assert len(state["nodes"]) == 2

            bad_status, _ = request(base + "/?event=up", b"{invalid-json")
            assert bad_status == 400
            state = json.loads(request(base + "/api/state")[1])
            assert state["counts"]["bad"] == 1
            bad_ts = state["last_bad"]["ts"]
            recovered = dict(up)
            recovered["deduplicationId"] = "smoke-enode1-002"
            recovered["fCnt"] = 249
            status, _ = request(base + "/?event=up", json.dumps(recovered).encode())
            assert status == 200
            state = json.loads(request(base + "/api/state")[1])
            assert state["last_good"] > bad_ts

            old_epoch = state["epoch"]
            status, body = request(base + "/api/clear", b"")
            assert status == 200
            new_epoch = json.loads(body)["epoch"]
            assert old_epoch != new_epoch
            state = json.loads(request(base + "/api/state")[1])
            assert len(state["nodes"]) == 2 and state["counts"]["http"] == 0
            assert all(not points for points in json.loads(request(base + "/api/series?since=0")[1])["series"].values())
            print("PASS: startup, HTTP ingest, decoding, metadata, series, raw, duplicate suppression, dynamic node, malformed JSON, clear-history")
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2)


if __name__ == "__main__":
    main()
