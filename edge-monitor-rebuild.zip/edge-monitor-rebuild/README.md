# Edge Monitor rebuild — ChirpStack + LoRaWAN

This bundle replaces the old small HTTP server with a backend that matches the uploaded modern `index.html`, and supplies revised sketches for the two uploaded ESP32 nodes.

## What it fixes

- **One API contract:** the backend provides every endpoint the UI uses: `/api/state`, `/api/series`, `/api/raw`, and `POST /api/clear`.
- **Both ingest paths:** subscribes to ChirpStack's MQTT event topics and accepts its HTTP integration callbacks (`/?event=up`, `/?event=join`, etc.). Duplicate MQTT/HTTP copies are suppressed.
- **Real diagnostics:** displays MQTT connection state, message counts, last topic, HTTP posts, invalid JSON, save status, frame-counter gaps, resets, and raw event JSON. Unknown EUIs become separate node cards instead of disappearing.
- **Persistent history:** atomically saves state and sensor series so a restart doesn't erase the readings. The clear button starts a new history epoch while keeping the node identities.
- **More honest labels:** a frame-counter gap is shown as a gap, not as proof that a particular radio packet was lost in the air. “Sequence continuity” is an estimate from received uplinks and observed counter gaps, not a measured delivery guarantee.
- **Firmware change:** both revised sketches retry a failed DHT read and still transmit a LoRaWAN frame, marking only the failed DHT values as unavailable. The original sketch returned early on DHT failure, skipped the radio send and skipped the 60-second delay. The revised sketches also validate stored buffer sizes and retry OTAA joins rather than stopping permanently after the first failed join.

The page uses the supplied dashboard's clean responsive design, light/dark theme, trends chart/table, event stream, node/radio details, and raw-message inspector.

## Install on the dashboard host

Copy `edge-monitor-rebuild.zip` to the machine that runs the dashboard, then run these commands there (as root, or with `sudo`):

```sh
unzip edge-monitor-rebuild.zip -d /root
cd /root/edge-monitor-rebuild
sudo ./install.sh
```

The installer backs up existing dashboard files under `/root/edge-monitor-backups/<timestamp>/`, stops only the existing `edge_dash.py` process/service (not unrelated Python processes), installs the new backend and page, and creates a `dashboard` command. On a systemd host it enables and starts `edge-monitor.service`.

Useful commands after install:

```sh
dashboard status
dashboard logs
dashboard restart
dashboard down
dashboard bg
```

Open `http://<dashboard-host-LAN-IP>:8026/` from a device on the same trusted network.

## ChirpStack integration

### MQTT (recommended)

The default is a broker on the same host as the dashboard:

```text
DASH_MQTT_HOST=127.0.0.1
DASH_MQTT_PORT=1883
DASH_MQTT_TOPIC='application/+/device/+/event/+'
```

The wildcard topic follows ChirpStack's documented event topic structure `application/APPLICATION_ID/device/DEV_EUI/event/EVENT`. If ChirpStack's MQTT broker is on another machine, edit `/etc/default/edge-monitor`, set `DASH_MQTT_HOST`, and set `DASH_MQTT_USER` / `DASH_MQTT_PASSWORD` if the broker requires them. Then run `dashboard restart`.

Check the dashboard's **MQTT connected** pill and the Diagnostics panel. `dashboard logs` shows connection errors and ingested events. If the broker's topic prefix is customized, adjust `DASH_MQTT_TOPIC` to match.

### HTTP integration (optional or alternative)

Set ChirpStack's HTTP integration event endpoint to:

```text
http://<dashboard-host-LAN-IP>:8026/
```

ChirpStack adds the event type in the `event` query parameter. Ensure the integration's encoding is **JSON**, not Protobuf. HTTP events update the same dashboard and are deduplicated against MQTT copies when ChirpStack provides the same `deduplicationId`.

You can use MQTT, HTTP, or both. If using HTTP only, set `DASH_MQTT_ENABLED=0` in `/etc/default/edge-monitor` and run `dashboard restart` so the dashboard doesn't report an unused MQTT connection as an error.

## Diagnosing Node 1

The uploaded log is a real `up` event for **ENode1 / `d251f42dc4918f96`**, frame counter **248**, received by gateway `a84041fdfe257d3b` at **2026-10-15 06:48:22 UTC (13:48:22 Vietnam time)**. The payload decodes to **28.8 °C, 32% humidity, moisture ADC 0**, with RSSI **−59 dBm** and SNR **14.2 dB**. That proves Node 1 transmitted successfully at that timestamp; it does not prove that it is currently sending.

The `curl` example posts a *simulated event* to the dashboard. It cannot make the physical sensor transmit. It also labels the sample `ENode1` and uses Node 1's EUI, so it isn't a test of Node 2.

After installing, check in this order:

1. `dashboard status` and `dashboard logs`; confirm **MQTT connected** or that HTTP posts increment.
2. Watch the event stream while a node should send. If MQTT is connected but no event for Node 1 appears, check ChirpStack's LoRaWAN Frames page for that EUI.
3. If ChirpStack shows uplinks but the dashboard doesn't, compare MQTT topic and HTTP integration logs. Make sure integration encoding is JSON and the topic prefix matches `/etc/default/edge-monitor`.
4. If ChirpStack shows no fresh uplink, inspect that physical node's Serial Monitor at 115200 baud. The revised sketch logs radio initialization, OTAA joins, DHT failure/retry, send results, and session-save problems. The original sketch's DHT `return` could silently skip the uplink each time the DHT sensor failed.

### Firmware caution

`ENode1_patched.ino` keeps the Node 1 credentials from `demo_Node.ino`; `ENode2_patched.ino` keeps the Node 2 credentials from `ENODE2.ino`. Flash the matching sketch to the matching physical device only. Review the retained credentials before sharing either file. I could validate the dashboard/API locally, but this environment has no Arduino CLI or your exact ESP32/RadioLib board package, so the sketches have **not** been compiled or tested on hardware here.

## Network and security

This dashboard has no user login; port 8026 is a trusted-LAN service, not an internet-facing site. Do not port-forward it to the public internet. Restrict access with your LAN firewall or VPN. If your broker is remote, use broker authentication and restrict network access to it.
